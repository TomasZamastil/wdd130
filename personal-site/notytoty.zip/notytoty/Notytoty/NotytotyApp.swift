//
//  NotytotyApp.swift
//  Notytoty
//
//  Created by Kristen Yose on 4/6/23.
//

import SwiftUI

@main
struct NotytotyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
